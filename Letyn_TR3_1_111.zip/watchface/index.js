﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let normal_temperature_current_text_img = ''
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('user_script_start.js');
            // start user_script_start.js

// экземпляр класса погодный провайдер// --------------------------------------------------------------------------------------------------------------------------
	
		class WeatherProvider {
		  constructor(props = {}) {
			this.props = {
				night_icons: [],											// индексы иконок для замены день-ночь
				index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
				show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
				temp_widget: null,											// виджет TEXT для отображения температуры
				temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
				temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
				temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
				description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
				cityName_widget: null,										// виджет TEXT для отображения названия города
				icon_widget: null,											// виджет IMG для отображения значка погоды
				time_sensor: null,											// сенсор времени, если не задан, то создается новый
				weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
				file_name: 'weather.json',									// имя файла с погодными данными
				auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
				lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
				...props,
			};

			this.providers = [
							{name: ['Zepp', 'Zepp'], appId: null},							// 0
						//	{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
							{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
						]

			this.description = [
					['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
					['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
				]

			this.last = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
				modTime: null,
			}

			if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
			if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
			if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
			if (this.props.auto_update) this.createHandlers();
		  }

		// создание обработчиков автоматического обновления погоды
			createHandlers() {
				this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

				this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				  resume_call: ( () => this.update() )
				})
			}
 
		// служебные функции
			arrayBufferToCyrillic(buffer) {
			  let result = '';
			  const bytes = new Uint8Array(buffer);

			  let i = 0;
			  while (i < bytes.length) {
				let byte1 = bytes[i++];
				
				if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
				  result += String.fromCharCode(byte1);
				} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
				  let byte2 = bytes[i++];
				  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
				  result += String.fromCharCode(charCode);
				} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
				  let byte2 = bytes[i++];
				  let byte3 = bytes[i++];
				  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
				  result += String.fromCharCode(charCode);
				}
			  }

			  return result
			}

		// чтение погодных данных из файла
			readFile(app_id) {
			  let str_result = "";
			  try {
				const [fs_stat, err] = hmFS.stat(this.props.file_name, {
				  appid: app_id,
				});
				if (err == 0) {
				  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
					appid: app_id,
				  });

				  const len = fs_stat.size;
				  let array_buffer = new ArrayBuffer(len);
				  hmFS.read(fh, array_buffer, 0, len);
				  hmFS.close(fh);
				  str_result = this.arrayBufferToCyrillic(array_buffer);

				  return str_result;
				} else {
				  console.log("err:", err);
				}
			  } catch (error) {
				console.log("error:", error);
				console.log("FAIL: No access to hmFS.");
			  }
			  return null;
			}

		// получить время последнего изменеия файла
			getFileModTime(app_id) {
				if (!app_id) return null
			  try {
				const [fs_stat, err] = hmFS.stat(this.props.file_name, {
				  appid: app_id,
				});
				
				if (err == 0) {
				  return fs_stat.mtime
				} else {
				  console.log("ModTime err:", err);
				}
			  } catch (error) {
				console.log("ModTime error:", error);
				console.log("FAIL: No access to hmFS.");
			  }
				return null
			}

		// проверка времени суток: возвращает true, если сейчас день
			isDayNow() {
				const sunData = this.props.weather_sensor.getForecastWeather().tideData;
				let sunriseMins = 8 * 60;			// время восхода
				let sunsetMins = 20 * 60;			// и заката по умолчанию

				if (sunData.count > 0){
					const today = sunData.data[0];
					sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
					sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
				}

				const curMins = curTime.hour * 60 + curTime.minute;
				const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

				return nowIsDay
			}


		// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
			getZeppIconIndex(index, app_id = null) {
				
				if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

				let newIndex = 25;
				
				if (app_id == 1065824) {					// WeatherService
					switch(index) {
					   case 1:
							newIndex = 3;
						break;
					   case 2:
							newIndex = 0;
						break;
					   case 3:
					   case 4:
							newIndex = 4;
						break;
					   case 5:
							newIndex = 1;
						break;
					   case 6:
							newIndex = 5;
						break;
					   case 7:
							newIndex = 10;
						break;
					   case 8:
							newIndex = 15;
						break;
					   case 9:
							newIndex = 6;
						break;
					   case 10:
							newIndex = 8;
						break;
					   case 11:
							newIndex = 9;
						break;
					   case 12:
							newIndex = 12;
						break;
					   case 13:
							newIndex = 13;
						break;
					   case 14:
							newIndex = 17;
						break;
					   default:
							newIndex = 25;
						break;
					}
				} else if (app_id == 1066654) {					// RuWeather
					newIndex = index - 1;
				}

				return newIndex
			}

		// температура со знаком
			tempWithSign(val){
				val = parseFloat(val);
				if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
				val = Math.round(val);
				// if (val > 0) val = '+' + val;
				val += '°';
				
				return val
			}

		//получение погодных данных из Zepp
			getZeppWeatherData() {
				const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
				const data = {
					weatherIcon: iconIndex,
					weatherDescription:  this.description[this.props.lang][iconIndex],
					temperature: this.props.weather_sensor.current ?? '--',
					temperatureFeels: '--',
					temperatureMax: this.props.weather_sensor.high ?? '--',
					temperatureMin: this.props.weather_sensor.low ?? '--',
					cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
				}

				return data
			}

		//получение погодных данных из файла приложения
			getAppWeatherData(app_id) {
				const data = {
					weatherIcon: 25,
					weatherDescription:  'Нет данных',
					temperature: '--',
					temperatureFeels: '--',
					temperatureMax: '--',
					temperatureMin: '--',
					cityName: '--',
				}

				// читаем данные из файла данных приложения
				let weather_str = this.readFile(app_id);
				let weatherJson = JSON.parse(weather_str);
		  
				if (weatherJson) {
					if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
					  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
					}

					if (weatherJson?.weatherDescriptionExtended?.length) {
					  data.weatherDescription = weatherJson.weatherDescriptionExtended;
					  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
					} else data.weatherDescription = this.description[data.weatherIcon];

					if (isFinite(weatherJson.temperature)) {
					  data.temperature = parseFloat(weatherJson.temperature);
					  data.temperature = Math.round(data.temperature);
					}
					
					if (isFinite(weatherJson.temperatureFeels)){
						data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
						data.temperatureFeels = Math.round(data.temperatureFeels);
					}
					  
					if (isFinite(weatherJson.temperatureMax)){
						data.temperatureMax = parseFloat(weatherJson.temperatureMax);
						data.temperatureMax = Math.round(data.temperatureMax);
					}
					  
					if (isFinite(weatherJson.temperatureMin)){
						data.temperatureMin = parseFloat(weatherJson.temperatureMin);
						data.temperatureMin = Math.round(data.temperatureMin);
					}
					
					if (weatherJson.city) {
					  data.cityName = weatherJson.city;
					}
				}
				
				return data
			}

		//получение погодных данных из файла приложения или Zepp
			getWeatherData(app_id = null) {
				if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
				else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
			}

		// обновить виджеты, используя данные текущего провайдера
			update() {
				let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

				const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
				
				if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
					const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
					this.last.modTime = modTime;

					let val = this.tempWithSign(newData.temperature);
					if (val != this.last.temperature){
						this.last.temperature = val;
						if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureMax);
					if (val != this.last.temperatureMax){
						this.last.temperatureMax = val;
						if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureMin);
					if (val != this.last.temperatureMin){
						this.last.temperatureMin = val;
						if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureFeels);
					if (val != this.last.temperatureFeels){
						this.last.temperatureFeels = val;
						if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = newData.cityName;
					if (val != this.last.cityName){
						this.last.cityName = val;
						if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = newData.weatherDescription;
					if (val != this.last.weatherDescription){
						this.last.weatherDescription = val;
						if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
					}

					
					curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
				}

				if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
					curIcon += 'n';
				}

				if (curIcon != this.last.weatherIcon){
					this.last.weatherIcon = curIcon;
					if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
				}
			}

		// переключить на следующего провайдера
			next(show_toast = this.props.show_toast) {
				const v = (this.props.index + 1) % this.providers.length;
				this.provider = v;
				if (show_toast) hmUI.showToast({text: this.name});
			}

		// переключить на предыдующего провайдера
			prev(show_toast = this.props.show_toast) {
				const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
				this.provider = v;
				if (show_toast) hmUI.showToast({text: this.name});
			}

		// установить провайдера по индексу
			set provider(v) {
				this.props.index = v;
				hmFS.SysProSetInt('WeatherProviderIndex', v);
				this.update();
			}

		// получить название текущего провайдера
			get name() {
				return this.providers[this.props.index].name[this.props.lang]
			}

		// получить название города
			get cityName() {
				return this.last.cityName
			}

		// получить текущую температуру
			get temperature() {
				return this.last.temperature
			}

		// получить максимальную температуру
			get temperatureMax() {
				return this.last.temperatureMax
			}

		// получить минимальную температуру
			get temperatureMin() {
				return this.last.temperatureMin
			}

		// получить ощущаемую температуру
			get temperatureFeels() {
				return this.last.temperatureFeels
			}

		// получить описание погоды
			get weatherDescription() {
				return this.last.weatherDescription
			}

		// удалить
		  delete() {
			this.providers = null;
			this.props = null;
			this.last = null;
			this.description = null;
			if (this.widgetDelegate) {
				hmUI.deleteWidget(this.widgetDelegate);
				this.widgetDelegate = null;
			}
		  }

		}
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 190,
              font_array: ["ds0120.png","ds0121.png","ds0122.png","ds0123.png","ds0124.png","ds0125.png","ds0126.png","ds0127.png","ds0128.png","ds0129.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 436,
              y: 191,
              src: 's036.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 365,
              font_array: ["ds0120.png","ds0121.png","ds0122.png","ds0123.png","ds0124.png","ds0125.png","ds0126.png","ds0127.png","ds0128.png","ds0129.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 127,
              y: 361,
              src: 's033.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 365,
              font_array: ["ds0120.png","ds0121.png","ds0122.png","ds0123.png","ds0124.png","ds0125.png","ds0126.png","ds0127.png","ds0128.png","ds0129.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 334,
              y: 394,
              src: 's032.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 's0001.png',
              center_x: 240,
              center_y: 240,
              x: 10,
              y: 238,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 232,
              y: 214,
              src: 's0017.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 85,
              src: 's0011.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 15,
              font_array: ["ds0120.png","ds0121.png","ds0122.png","ds0123.png","ds0124.png","ds0125.png","ds0126.png","ds0127.png","ds0128.png","ds0129.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 16,
              src: 's033.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 35,
              y: 192,
              image_array: ["s0018.png","s0019.png","s0020.png","s0021.png","s0022.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 64,
              font_array: ["ds0120.png","ds0121.png","ds0122.png","ds0123.png","ds0124.png","ds0125.png","ds0126.png","ds0127.png","ds0128.png","ds0129.png"],
              padding: false,
              h_space: 1,
              dot_image: 's034.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 358,
              y: 75,
              src: 's0007.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 64,
              font_array: ["ds0120.png","ds0121.png","ds0122.png","ds0123.png","ds0124.png","ds0125.png","ds0126.png","ds0127.png","ds0128.png","ds0129.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 70,
              src: 'S031.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 99,
              y: 128,
              week_en: ["ww001.png","ww002.png","ww003.png","ww004.png","ww005.png","ww006.png","ww007.png"],
              week_tc: ["ww001.png","ww002.png","ww003.png","ww004.png","ww005.png","ww006.png","ww007.png"],
              week_sc: ["ww001.png","ww002.png","ww003.png","ww004.png","ww005.png","ww006.png","ww007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 104,
              month_startY: 310,
              month_sc_array: ["mm001.png","mm002.png","mm003.png","mm004.png","mm005.png","mm006.png","mm007.png","mm008.png","mm009.png","mm010.png","mm011.png","mm012.png"],
              month_tc_array: ["mm001.png","mm002.png","mm003.png","mm004.png","mm005.png","mm006.png","mm007.png","mm008.png","mm009.png","mm010.png","mm011.png","mm012.png"],
              month_en_array: ["mm001.png","mm002.png","mm003.png","mm004.png","mm005.png","mm006.png","mm007.png","mm008.png","mm009.png","mm010.png","mm011.png","mm012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 17,
              day_startY: 235,
              day_sc_array: ["dm0000.png","dm0001.png","dm0002.png","dm0003.png","dm0004.png","dm0005.png","dm0006.png","dm0007.png","dm0008.png","dm0009.png"],
              day_tc_array: ["dm0000.png","dm0001.png","dm0002.png","dm0003.png","dm0004.png","dm0005.png","dm0006.png","dm0007.png","dm0008.png","dm0009.png"],
              day_en_array: ["dm0000.png","dm0001.png","dm0002.png","dm0003.png","dm0004.png","dm0005.png","dm0006.png","dm0007.png","dm0008.png","dm0009.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 183,
              hour_array: ["b0017.png","b0018.png","b0019.png","b0020.png","b0021.png","b0022.png","b0023.png","b0024.png","b0025.png","b0026.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 255,
              minute_startY: 183,
              minute_array: ["b0017.png","b0018.png","b0019.png","b0020.png","b0021.png","b0022.png","b0023.png","b0024.png","b0025.png","b0026.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 404,
              second_startY: 234,
              second_array: ["dm0000.png","dm0001.png","dm0002.png","dm0003.png","dm0004.png","dm0005.png","dm0006.png","dm0007.png","dm0008.png","dm0009.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 398,
              font_array: ["dm0000.png","dm0001.png","dm0002.png","dm0003.png","dm0004.png","dm0005.png","dm0006.png","dm0007.png","dm0008.png","dm0009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 's0030.png',
              unit_tc: 's0030.png',
              unit_en: 's0030.png',
              negative_image: 's0029.png',
              invalid_image: 'w0031.png',
              align_h: hmUI.align.CENTER_H,

            });
const weatherImg = hmUI.createWidget(hmUI.widget.IMG, {
  x: 247,
  y: 400,
  w: 60,
  h: 60,
  src: 'w_25.png',
});
			
        // экземпляр класса погодный провайдер		
            const weatherProvider = new WeatherProvider({
	            show_toast: true,                           // показывать всплывающее сообщение при переключении провайдера
	            temp_widget: normal_temperature_current_text_img, 
		    icon_widget: weatherImg,						
            });
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 182,
              hour_array: ["d0000.png","d0001.png","d0002.png","d0003.png","d0004.png","d0005.png","d0006.png","d0007.png","d0008.png","d0009.png"],
              hour_zero: 1,
              hour_space: 11,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 269,
              minute_startY: 182,
              minute_array: ["d0000.png","d0001.png","d0002.png","d0003.png","d0004.png","d0005.png","d0006.png","d0007.png","d0008.png","d0009.png"],
              minute_zero: 1,
              minute_space: 11,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 188,
              src: 's0028.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 0,
              w: 100,
              h: 63,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 189,
              w: 106,
              h: 106,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 12,
              y: 187,
              w: 77,
              h: 106,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 349,
              w: 111,
              h: 79,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 62,
              w: 106,
              h: 57,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 270,
              y: 63,
              w: 106,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 357,
              w: 100,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1066654, url: 'page/index', params: { from_wf: true} });
              }, // end func
              longpress_func: (button_widget) => {
                weatherProvider.next();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0004.png',
              center_x: 240,
              center_y: 240,
              x: 9,
              y: 240,
              start_angle: -45,
              end_angle: 315,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
         
hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0004.png',
              center_x: 240,
              center_y: 240,
              x: 9,
              y: 240,
              start_angle: -45,
              end_angle: 315,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script_end.js


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}